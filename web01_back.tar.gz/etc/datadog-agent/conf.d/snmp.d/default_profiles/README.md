The `default_profiles` folder is used to store datadog default profiles.
